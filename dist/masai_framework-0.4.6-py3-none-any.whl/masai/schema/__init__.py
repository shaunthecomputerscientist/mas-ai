"""
Custom schema classes to replace LangChain dependencies.
"""

from .document import Document

__all__ = ["Document"]

