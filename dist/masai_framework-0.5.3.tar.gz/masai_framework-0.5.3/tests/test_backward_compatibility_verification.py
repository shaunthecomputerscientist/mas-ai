"""
Quick backward compatibility verification.
Verifies that all existing functionality still works after Phase 1 & 2 changes.
"""

import os
import sys
import asyncio
from typing import List

# Ensure 'src' is on path for local imports
sys.path.insert(0, os.path.abspath("src"))

from masai.Memory.LongTermMemory import (
    RedisConfig,
    QdrantConfig,
    LongTermMemory,
)
from masai.schema import Document


def _toy_embed(texts: List[str]) -> List[List[float]]:
    """Toy embedder for tests."""
    import numpy as np
    dim = 32
    vecs = []
    for t in texts:
        v = np.zeros(dim, dtype=float)
        for tok in str(t).lower().split():
            h = abs(hash(tok)) % dim
            v[h] += 1.0
        n = np.linalg.norm(v)
        if n > 0:
            v = v / n
        vecs.append(v.tolist())
    return vecs


async def test_backward_compatibility():
    """Test backward compatibility after changes."""
    print("\n" + "="*70)
    print("BACKWARD COMPATIBILITY VERIFICATION")
    print("="*70 + "\n")

    # Test 1: RedisConfig can be created with all old parameters
    print("Test 1: RedisConfig initialization...")
    redis_config = RedisConfig(
        redis_url="redis://localhost:6379",
        index_name="test_index",
        vector_size=32,
        embedding_model=_toy_embed,
        distance_metric="cosine",
        dedup_mode="similarity",
        dedup_similarity_threshold=0.95,
        use_async=True,
        batch_size=100,
        ttl_seconds=None,
    )
    assert redis_config.redis_url == "redis://localhost:6379"
    assert redis_config.index_name == "test_index"
    print("  ✅ RedisConfig works with all parameters")

    # Test 2: QdrantConfig can be created with all old parameters
    print("\nTest 2: QdrantConfig initialization...")
    qdrant_config = QdrantConfig(
        url="http://localhost:6333",
        collection_name="test_collection",
        vector_size=32,
        embedding_model=_toy_embed,
        distance="cosine",
        dedup_mode="similarity",
    )
    assert qdrant_config.url == "http://localhost:6333"
    assert qdrant_config.collection_name == "test_collection"
    print("  ✅ QdrantConfig works with all parameters")

    # Test 3: LongTermMemory can be initialized with Redis config
    print("\nTest 3: LongTermMemory with Redis backend...")
    ltm_redis = LongTermMemory(redis_config)
    assert ltm_redis.backend_type == "redis"
    assert hasattr(ltm_redis, 'save')
    assert hasattr(ltm_redis, 'search')
    assert hasattr(ltm_redis, '_get_user_lock')  # New: locks
    print("  ✅ LongTermMemory initializes with Redis config")

    # Test 4: LongTermMemory can be initialized with Qdrant config
    print("\nTest 4: LongTermMemory with Qdrant backend...")
    ltm_qdrant = LongTermMemory(qdrant_config)
    assert ltm_qdrant.backend_type == "qdrant"
    assert hasattr(ltm_qdrant, 'save')
    assert hasattr(ltm_qdrant, 'search')
    assert hasattr(ltm_qdrant, '_get_user_lock')  # New: locks
    print("  ✅ LongTermMemory initializes with Qdrant config")

    # Test 5: LongTermMemory can be initialized with dict config
    print("\nTest 5: LongTermMemory with dict config (Redis)...")
    dict_config = {
        "redis_url": "redis://localhost:6379",
        "index_name": "test_index",
        "vector_size": 32,
        "embedding_model": _toy_embed,
    }
    ltm_dict = LongTermMemory(dict_config)
    assert ltm_dict.backend_type == "redis"
    print("  ✅ LongTermMemory works with dict config")

    # Test 6: Verify save() method signature unchanged
    print("\nTest 6: LongTermMemory.save() signature...")
    import inspect
    save_sig = inspect.signature(ltm_redis.save)
    params = list(save_sig.parameters.keys())
    assert params == ['user_id', 'documents'], f"Expected ['user_id', 'documents'], got {params}"
    assert inspect.iscoroutinefunction(ltm_redis.save)
    print("  ✅ save() signature unchanged")

    # Test 7: Verify search() method signature unchanged
    print("\nTest 7: LongTermMemory.search() signature...")
    search_sig = inspect.signature(ltm_redis.search)
    params = list(search_sig.parameters.keys())
    expected = ['user_id', 'query', 'k', 'categories']
    assert params == expected, f"Expected {expected}, got {params}"
    assert inspect.iscoroutinefunction(ltm_redis.search)
    print("  ✅ search() signature unchanged")

    # Test 8: Verify adapter methods exist
    print("\nTest 8: Adapter methods...")
    assert hasattr(ltm_redis.adapter, 'upsert_documents')
    assert hasattr(ltm_redis.adapter, 'search')
    assert hasattr(ltm_redis.adapter, 'flush')
    assert hasattr(ltm_redis.adapter, 'redis_client')  # New: pooled property
    print("  ✅ All adapter methods exist")

    # Test 9: Verify locks work
    print("\nTest 9: Per-user locks functionality...")
    lock1 = await ltm_redis._get_user_lock("user1")
    lock2 = await ltm_redis._get_user_lock("user1")
    lock3 = await ltm_redis._get_user_lock("user2")
    assert lock1 is lock2, "Same user should get same lock"
    assert lock1 is not lock3, "Different users should get different locks"
    print("  ✅ Per-user locks work correctly")

    # Test 10: Concurrent operations don't block across users
    print("\nTest 10: Concurrent operations (different users)...")
    import time
    execution_times = {}

    async def simulate_operation(user_id, duration):
        start = time.time()
        lock = await ltm_redis._get_user_lock(user_id)
        async with lock:
            await asyncio.sleep(duration)
        execution_times[user_id] = time.time() - start

    start = time.time()
    await asyncio.gather(
        simulate_operation("user1", 0.05),
        simulate_operation("user2", 0.05),
    )
    total_time = time.time() - start

    # Should run in parallel (~0.05s), not sequential (~0.1s)
    assert total_time < 0.08, f"Should parallelize, took {total_time:.3f}s"
    print(f"  ✅ Concurrent operations parallelize (total: {total_time:.3f}s)")

    print("\n" + "="*70)
    print("✅ ALL BACKWARD COMPATIBILITY TESTS PASSED")
    print("="*70)
    print("\nChanges are fully compatible:")
    print("  ✅ All existing APIs work unchanged")
    print("  ✅ All parameters accepted")
    print("  ✅ Method signatures unchanged")
    print("  ✅ New features (locks, pooling) integrated seamlessly")
    print("  ✅ No breaking changes detected")
    print()


if __name__ == "__main__":
    try:
        asyncio.run(test_backward_compatibility())
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
