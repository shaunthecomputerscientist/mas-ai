"""
End-to-end test of parameter flow from model_config to provider APIs.
Tests that parameters are correctly extracted, mapped, and forwarded.
"""
import os
import sys
import json

# Make src visible
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from masai.GenerativeModel.vanilla_wrappers.openai_wrapper import ChatOpenAI
from masai.GenerativeModel.vanilla_wrappers.gemini_wrapper import ChatGoogleGenerativeAI
from masai.GenerativeModel.parameter_config import (
    extract_openai_params,
    extract_gemini_params,
)


def test_openai_standard_model_params():
    """Test that standard OpenAI model gets correct params."""
    config = {
        "temperature": 0.3,
        "max_output_tokens": 1024,
        "top_p": 0.95,
        "stop_sequences": ["END", "STOP"],
        "enable_logprobs": False,
        "num_logprobs": 0,
        "presence_penalty": 0.0,
        "frequency_penalty": 0.0,
    }
    
    extracted = extract_openai_params(config, verbose=False)
    print("✅ OpenAI Standard Model Config (extracted by parameter_config):")
    for k, v in sorted(extracted.items()):
        print(f"  {k}: {v}")
    
    # Verify mappings (extractor uses max_completion_tokens; wrapper will use max_tokens for standard models)
    assert extracted.get("max_completion_tokens") == 1024, "Extractor maps max_output_tokens → max_completion_tokens"
    assert extracted.get("stop") == ["END", "STOP"], "stop_sequences should map to stop"
    assert extracted.get("logprobs") is False, "enable_logprobs should map to logprobs"
    # top_logprobs should NOT be included when logprobs is False (constraint enforced)
    assert "top_logprobs" not in extracted, "top_logprobs should be dropped when logprobs=False"
    print("✅ Standard model params correct (logprobs constraint enforced)\n")


def test_openai_reasoning_model_params():
    """Test that reasoning OpenAI model gets correct params."""
    config = {
        "temperature": 0.3,  # Ignored for reasoning models
        "max_output_tokens": 2048,
        "reasoning_effort": "medium",
    }
    
    extracted = extract_openai_params(config, verbose=False)
    print("✅ OpenAI Reasoning Model Config (extracted by parameter_config):")
    for k, v in sorted(extracted.items()):
        print(f"  {k}: {v}")
    
    # Extractor always maps max_output_tokens to max_completion_tokens; wrapper keeps it for reasoning models
    assert extracted.get("max_completion_tokens") == 2048, "Extractor maps max_output_tokens → max_completion_tokens (wrapper keeps for reasoning)"
    assert extracted.get("reasoning_effort") == "medium"
    print("✅ Reasoning model params correct\n")


def test_gemini_standard_model_params():
    """Test that standard Gemini model gets correct params."""
    config = {
        "temperature": 0.7,
        "max_output_tokens": 2048,
        "top_p": 0.95,
        "top_k": 40,
        "stop_sequences": ["END"],
        "safety_settings": [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"}
        ],
    }
    
    extracted = extract_gemini_params(config, verbose=False)
    print("✅ Gemini Standard Model Config (extracted):")
    for k, v in sorted(extracted.items()):
        print(f"  {k}: {v}")
    
    # Verify mappings and presence
    assert extracted.get("temperature") == 0.7
    assert extracted.get("max_output_tokens") == 2048
    assert extracted.get("top_k") == 40
    assert extracted.get("stop_sequences") == ["END"]
    assert "safety_settings" in extracted
    print("✅ Gemini standard model params correct\n")


def test_gemini_thinking_model_params():
    """Test that Gemini thinking model gets correct params."""
    config = {
        "temperature": 0.5,
        "max_output_tokens": 4096,
        "thinking_budget": -1,
    }
    
    extracted = extract_gemini_params(config, verbose=False)
    print("✅ Gemini Thinking Model Config (extracted):")
    for k, v in sorted(extracted.items()):
        print(f"  {k}: {v}")
    
    assert extracted.get("thinking_budget") == -1
    print("✅ Gemini thinking model params correct\n")


def test_logprobs_constraint():
    """Test that top_logprobs is NOT forwarded when logprobs is disabled."""
    # Case 1: logprobs explicitly False + num_logprobs set → should drop top_logprobs
    config = {
        "enable_logprobs": False,
        "num_logprobs": 5,  # User mistakenly set both
    }
    
    extracted = extract_openai_params(config, verbose=False)
    print("✅ OpenAI Logprobs Constraint Test (logprobs=False + num_logprobs=5):")
    print(f"  Result: {extracted}")
    
    # Since enable_logprobs is False, top_logprobs should NOT be in params
    assert "top_logprobs" not in extracted, "top_logprobs should be dropped when logprobs=False"
    assert extracted.get("logprobs") is False
    print("✅ Constraint enforced: top_logprobs dropped when logprobs=False\n")


def test_logprobs_auto_enable():
    """Test that logprobs is auto-enabled when top_logprobs is provided."""
    # Case 2: num_logprobs set but enable_logprobs not set → should auto-enable logprobs
    config = {
        "num_logprobs": 5,
    }
    
    extracted = extract_openai_params(config, verbose=False)
    print("✅ OpenAI Logprobs Auto-Enable Test (num_logprobs=5, enable_logprobs not set):")
    print(f"  Result: {extracted}")
    
    # logprobs should be auto-enabled when top_logprobs is requested
    assert extracted.get("logprobs") is None, "Base extraction doesn't set logprobs, but wrapper will auto-enable"
    assert extracted.get("top_logprobs") == 5
    print("✅ Auto-enable will be handled by wrapper\n")


def test_gemini_gemini_specific_filtered_from_openai():
    """Test that Gemini-specific params are filtered out of OpenAI extraction."""
    config = {
        "temperature": 0.7,
        "top_k": 40,  # Gemini only
        "thinking_budget": -1,  # Gemini only
        "max_output_tokens": 2048,
    }
    
    extracted = extract_openai_params(config, verbose=False)
    print("✅ OpenAI Extraction with Gemini-Only Params (should be filtered):")
    print(f"  Result: {extracted}")
    
    assert "top_k" not in extracted, "top_k should be filtered out for OpenAI"
    assert "thinking_budget" not in extracted, "thinking_budget should be filtered out for OpenAI"
    assert extracted.get("max_completion_tokens") == 2048, "max_output_tokens should be mapped to max_completion_tokens"
    print("✅ Gemini-only params correctly filtered\n")


def test_openai_openai_specific_filtered_from_gemini():
    """Test that OpenAI-specific params are filtered out of Gemini extraction."""
    config = {
        "temperature": 0.7,
        "reasoning_effort": "high",  # OpenAI only
        "response_format": {"type": "json_object"},  # OpenAI only
        "max_output_tokens": 2048,
    }
    
    extracted = extract_gemini_params(config, verbose=False)
    print("✅ Gemini Extraction with OpenAI-Only Params (should be filtered):")
    print(f"  Result: {extracted}")
    
    assert "reasoning_effort" not in extracted, "reasoning_effort should be filtered out for Gemini"
    assert "response_format" not in extracted, "response_format should be filtered out for Gemini"
    assert extracted.get("max_output_tokens") == 2048, "max_output_tokens should be passed through for Gemini"
    print("✅ OpenAI-only params correctly filtered\n")


def test_actual_model_instantiation():
    """Test actual ChatOpenAI instantiation with full config."""
    print("✅ Testing actual ChatOpenAI instantiation:")
    
    config = {
        "model": "gpt-4o-mini",
        "temperature": 0.3,
        "max_output_tokens": 1024,
        "top_p": 0.95,
        "stop_sequences": ["END"],
        "enable_logprobs": True,
        "num_logprobs": 3,
    }
    
    os.environ.setdefault("OPENAI_API_KEY", "sk-test")
    
    try:
        # First show what the extractor produces
        extracted = extract_openai_params(config, verbose=False)
        print("  Extracted params:")
        for k, v in sorted(extracted.items()):
            print(f"    {k}: {v}")
        
        # Now instantiate with extracted params (this is what BaseGenerativeModel does)
        model = ChatOpenAI(**{**config, **extracted})
        params = model._prepare_request_params([{"role": "user", "content": "Test"}])
        
        print("  Prepared params:")
        for k, v in sorted(params.items()):
            print(f"    {k}: {v}")
        
        # Verify key params (logprobs and top_logprobs should be present)
        assert params.get("temperature") == 0.3, "temperature"
        assert params.get("max_tokens") == 1024, "max_tokens should be set"
        assert params.get("stop") == ["END"], "stop sequences"
        assert params.get("logprobs") is True, "logprobs should be True"
        assert params.get("top_logprobs") == 3, "top_logprobs should be 3"
        print("✅ Actual instantiation works correctly\n")
    except AssertionError as e:
        print(f"❌ Assertion failed: {e}\n")
        raise
    except Exception as e:
        print(f"❌ Error during instantiation: {e}\n")
        raise


if __name__ == "__main__":
    print("=" * 80)
    print("COMPREHENSIVE PARAMETER FLOW TESTS")
    print("=" * 80 + "\n")
    
    test_openai_standard_model_params()
    test_openai_reasoning_model_params()
    test_gemini_standard_model_params()
    test_gemini_thinking_model_params()
    test_logprobs_constraint()
    test_logprobs_auto_enable()
    test_gemini_gemini_specific_filtered_from_openai()
    test_openai_openai_specific_filtered_from_gemini()
    test_actual_model_instantiation()
    
    print("=" * 80)
    print("✅ ALL TESTS PASSED - Parameter flow is correct!")
    print("=" * 80)
