"""
Debug test to see what's being filtered and what's not.
"""

import os
import sys

# Ensure 'src' is on path for local imports
sys.path.insert(0, os.path.abspath("src"))

from masai.GenerativeModel.parameter_config import MAPPED_PARAMS, MASAI_SPECIFIC_PARAMS, GEMINI_SPECIFIC_PARAMS, OPENAI_SPECIFIC_PARAMS

# Show what parameters are being filtered
print("="*70)
print("PARAMETER FILTERING DEBUG")
print("="*70)

print("\n1. MAPPED_PARAMS mapping:")
for std_name, mapping in MAPPED_PARAMS.items():
    print(f"   {std_name}:")
    for provider, provider_name in mapping.items():
        print(f"      {provider}: {provider_name}")

print("\n2. Provider-specific names extracted from MAPPED_PARAMS:")
params_to_filter = set()
for param_mapping in MAPPED_PARAMS.values():
    params_to_filter.update(param_mapping.values())
print(f"   {sorted(params_to_filter)}")

print("\n3. Check if 'max_tokens' is in filtered set:")
print(f"   'max_tokens' in params_to_filter: {'max_tokens' in params_to_filter}")

print("\n4. Check if 'max_completion_tokens' is in filtered set:")
print(f"   'max_completion_tokens' in params_to_filter: {'max_completion_tokens' in params_to_filter}")

print("\n5. Check if 'stop' is in filtered set:")
print(f"   'stop' in params_to_filter: {'stop' in params_to_filter}")

print("\n" + "="*70)

# Now test with actual ChatOpenAI
from masai.GenerativeModel.vanilla_wrappers import ChatOpenAI

print("\nTesting ChatOpenAI with max_tokens passed:")
model = ChatOpenAI(
    model="gpt-4o",
    temperature=0.7,
    api_key="test-key",
    max_output_tokens=2048,
    max_tokens=9999,  # Should be filtered
)

print(f"   model.extra_kwargs: {model.extra_kwargs}")
print(f"   'max_tokens' in extra_kwargs: {'max_tokens' in model.extra_kwargs}")
print(f"   model.max_output_tokens: {model.max_output_tokens}")

print("\n" + "="*70)
