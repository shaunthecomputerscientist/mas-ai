import os
import sys

# Ensure the project's `src` package is on sys.path for tests run from repository root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from masai.GenerativeModel.vanilla_wrappers.openai_wrapper import ChatOpenAI


def test_top_logprobs_enables_logprobs():
    model = ChatOpenAI(model="gpt-4o-mini", api_key="sk-test", top_logprobs=5)
    params = model._prepare_request_params([{"role": "user", "content": "Hello"}])

    assert params.get("logprobs") is True, "logprobs should be enabled when top_logprobs is provided"
    assert params.get("top_logprobs") == 5


def test_logprobs_without_top_logprobs():
    model = ChatOpenAI(model="gpt-4o-mini", api_key="sk-test", logprobs=True)
    params = model._prepare_request_params([{"role": "user", "content": "Hello"}])

    assert params.get("logprobs") is True
    assert "top_logprobs" not in params


def test_top_logprobs_in_extra_kwargs_enables_logprobs():
    model = ChatOpenAI(model="gpt-4o-mini", api_key="sk-test")
    # Simulate top_logprobs making it into extra_kwargs (defensive case)
    model.extra_kwargs = {"top_logprobs": 4}
    params = model._prepare_request_params([{"role": "user", "content": "Hello"}])

    assert params.get("logprobs") is True
    assert params.get("top_logprobs") == 4
