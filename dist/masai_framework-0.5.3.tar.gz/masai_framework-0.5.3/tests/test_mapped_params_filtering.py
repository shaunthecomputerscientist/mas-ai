"""
Test to verify that provider-specific mapped parameters are properly filtered.

This test verifies that:
1. max_tokens is filtered (OpenAI version of max_output_tokens)
2. max_completion_tokens is filtered (OpenAI reasoning model version)
3. stop is filtered (OpenAI version of stop_sequences)
4. Other provider-specific mapped params are filtered
5. No conflicts occur between mapped parameter versions
"""

import os
import sys

# Ensure 'src' is on path for local imports
sys.path.insert(0, os.path.abspath("src"))

from masai.GenerativeModel.vanilla_wrappers import ChatOpenAI


def test_provider_specific_params_filtered():
    """Test that provider-specific parameter versions are filtered from extra_kwargs."""
    print("\nTest 1: Provider-specific mapped params filtered...")
    
    try:
        # Test that provider-specific versions are filtered
        model = ChatOpenAI(
            model="gpt-4o",  # Standard model (uses max_tokens)
            temperature=0.7,
            api_key="test-key",
            max_output_tokens=2048,  # MASAI standardized name
            max_tokens=4096,  # OpenAI provider-specific (should be filtered)
            max_completion_tokens=8192,  # OpenAI reasoning-specific (should be filtered)
            stop="END",  # OpenAI version (should be filtered)
            stop_sequences=["STOP"],  # MASAI standardized (already handled)
            enable_logprobs=True,  # MASAI standardized
            logprobs=True,  # OpenAI version (should be filtered)
            top_logprobs=5,  # OpenAI version (should be filtered)
            num_logprobs=10,  # MASAI standardized
            unknown_param="should_pass"  # Unknown (should pass through)
        )
        
        # Verify no provider-specific versions in extra_kwargs
        assert "max_tokens" not in model.extra_kwargs, "max_tokens should be filtered"
        assert "max_completion_tokens" not in model.extra_kwargs, "max_completion_tokens should be filtered"
        assert "stop" not in model.extra_kwargs, "stop should be filtered"
        assert "logprobs" not in model.extra_kwargs, "logprobs should be filtered"
        assert "top_logprobs" not in model.extra_kwargs, "top_logprobs should be filtered"
        
        # Verify standardized names are also filtered
        assert "max_output_tokens" not in model.extra_kwargs, "max_output_tokens should be filtered"
        assert "stop_sequences" not in model.extra_kwargs, "stop_sequences should be filtered"
        assert "enable_logprobs" not in model.extra_kwargs, "enable_logprobs should be filtered"
        assert "num_logprobs" not in model.extra_kwargs, "num_logprobs should be filtered"
        
        # Verify unknown params pass through
        assert "unknown_param" in model.extra_kwargs, "unknown_param should pass through"
        assert model.extra_kwargs["unknown_param"] == "should_pass"
        
        print("  ✅ All provider-specific parameter versions filtered correctly")
        return True
    except AssertionError as e:
        print(f"  ❌ FAILED: {e}")
        return False


def test_no_duplicate_max_tokens():
    """Test that standard models use max_tokens and not max_completion_tokens."""
    print("\nTest 2: No duplicate max_tokens/max_completion_tokens...")
    
    try:
        model = ChatOpenAI(
            model="gpt-4o",  # Standard model
            temperature=0.7,
            api_key="test-key",
            max_output_tokens=2048,
            max_tokens=9999,  # Try to pass through directly
            max_completion_tokens=9999  # Try to pass through directly
        )
        
        # Prepare request params
        messages = [{"role": "user", "content": "test"}]
        params = model._prepare_request_params(messages)
        
        # For standard models, should only have max_tokens
        assert "max_tokens" in params, "max_tokens should be in params for standard model"
        assert params["max_tokens"] == 2048, f"max_tokens should be 2048 (from max_output_tokens), got {params['max_tokens']}"
        
        # Should NOT have max_completion_tokens (that's for reasoning models)
        assert "max_completion_tokens" not in params, "max_completion_tokens should NOT be in params for standard model"
        
        print("  ✅ Standard model correctly uses max_tokens only")
        return True
    except AssertionError as e:
        print(f"  ❌ FAILED: {e}")
        return False


def test_reasoning_model_uses_correct_param():
    """Test that reasoning models use max_completion_tokens."""
    print("\nTest 3: Reasoning models use max_completion_tokens...")
    
    try:
        model = ChatOpenAI(
            model="gpt-5",  # Reasoning model
            temperature=0.7,  # Will be ignored
            api_key="test-key",
            max_output_tokens=4096,
            reasoning_effort="high"
        )
        
        # Prepare request params
        messages = [{"role": "user", "content": "test"}]
        params = model._prepare_request_params(messages)
        
        # For reasoning models, should have max_completion_tokens
        assert "max_completion_tokens" in params, "max_completion_tokens should be in params for reasoning model"
        assert params["max_completion_tokens"] == 4096, f"max_completion_tokens should be 4096, got {params['max_completion_tokens']}"
        
        # Should NOT have max_tokens
        assert "max_tokens" not in params, "max_tokens should NOT be in params for reasoning model"
        
        print("  ✅ Reasoning model correctly uses max_completion_tokens only")
        return True
    except AssertionError as e:
        print(f"  ❌ FAILED: {e}")
        return False


def test_no_conflicting_params_in_final_request():
    """Test that final API request has no conflicting parameters."""
    print("\nTest 4: Final request has no conflicting parameters...")
    
    try:
        # Standard model
        model_std = ChatOpenAI(
            model="gpt-4o",
            temperature=0.7,
            api_key="test-key",
            max_output_tokens=2048,
            stop=["END"],
            max_tokens=9999,  # Try to inject conflicting param
        )
        
        messages = [{"role": "user", "content": "test"}]
        params_std = model_std._prepare_request_params(messages)
        
        # Verify only one max_* parameter
        max_params = [k for k in params_std.keys() if k.startswith('max_')]
        assert len(max_params) == 1, f"Should have only 1 max_* param, got {max_params}"
        assert max_params[0] == "max_tokens", f"Should be max_tokens for standard model, got {max_params}"
        
        # Verify stop is not duplicated
        assert params_std.get("stop") == ["END"], "stop should be set from init"
        
        print("  ✅ Final request has no conflicting parameters")
        return True
    except AssertionError as e:
        print(f"  ❌ FAILED: {e}")
        return False


if __name__ == "__main__":
    print("="*70)
    print("TESTING PROVIDER-SPECIFIC PARAMETER FILTERING")
    print("="*70)
    
    all_passed = True
    
    all_passed &= test_provider_specific_params_filtered()
    all_passed &= test_no_duplicate_max_tokens()
    all_passed &= test_reasoning_model_uses_correct_param()
    all_passed &= test_no_conflicting_params_in_final_request()
    
    print("\n" + "="*70)
    if all_passed:
        print("✅ ALL TESTS PASSED")
        print("="*70)
        print("\nThe error 'Setting max_tokens and max_completion_tokens at the")
        print("same time is not supported' should no longer occur.")
        sys.exit(0)
    else:
        print("❌ SOME TESTS FAILED")
        print("="*70)
        sys.exit(1)
