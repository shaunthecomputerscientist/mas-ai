"""
Targeted tests for Phase 1 (Connection Pooling) and Phase 2 (Async Locks) fixes.

Tests verify:
1. Connection pooling: Single client reuse, no memory leak, proper cleanup
2. Async locks: Per-user serialization, cross-user parallelization, no race conditions
3. Backward compatibility: All existing functionality preserved
4. Integration: Both Qdrant and Redis backends work correctly
"""

import os
import sys
import asyncio
import uuid
import time
from typing import List
from unittest.mock import Mock, AsyncMock, patch, MagicMock

# Ensure 'src' is on path for local imports
sys.path.insert(0, os.path.abspath("src"))

from masai.Memory.LongTermMemory import (
    RedisConfig,
    RedisAdapter,
    QdrantConfig,
    QdrantAdapter,
    LongTermMemory,
)
from masai.schema import Document


def _toy_embed(texts: List[str]) -> List[List[float]]:
    """Toy embedder for tests."""
    import numpy as np
    dim = 32
    vecs = []
    for t in texts:
        v = np.zeros(dim, dtype=float)
        for tok in str(t).lower().split():
            h = abs(hash(tok)) % dim
            v[h] += 1.0
        n = np.linalg.norm(v)
        if n > 0:
            v = v / n
        vecs.append(v.tolist())
    return vecs


# ============================================================================
# PHASE 1: CONNECTION POOLING TESTS
# ============================================================================

class TestRedisConnectionPooling:
    """Test Phase 1: Connection pooling fixes for Redis."""

    def test_redis_adapter_creates_pool_at_init(self):
        """Verify RedisAdapter creates connection pool at initialization."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
            use_async=True,
        )
        adapter = RedisAdapter(config)

        # Verify pool was created
        assert adapter._redis_client is not None, "redis_client should be created at init"
        print("✅ Connection pool created at initialization")

    def test_redis_client_property_returns_same_instance(self):
        """Verify redis_client property always returns the same cached instance (no new clients)."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
            use_async=True,
        )
        adapter = RedisAdapter(config)

        # Get client multiple times
        client1 = adapter.redis_client
        client2 = adapter.redis_client
        client3 = adapter.redis_client

        # All should be the same object (identity check)
        assert client1 is client2, "Should return same cached instance"
        assert client2 is client3, "Should return same cached instance"
        assert id(client1) == id(client2), "Object IDs should match"
        print("✅ redis_client property returns same cached instance (no new clients created)")

    def test_redis_adapter_has_close_method(self):
        """Verify close() method exists for graceful cleanup."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
            use_async=True,
        )
        adapter = RedisAdapter(config)

        # Verify close method exists
        assert hasattr(adapter, 'close'), "close() method should exist"
        assert callable(adapter.close), "close() should be callable"
        print("✅ close() method exists for graceful cleanup")

    def test_redis_adapter_no_new_client_on_repeated_access(self):
        """Verify multiple redis_client accesses don't create new clients."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
            use_async=True,
        )
        adapter = RedisAdapter(config)

        # Simulate multiple method calls that would use redis_client
        initial_client = adapter.redis_client
        
        # Access many times (would create 100+ clients with old code)
        for _ in range(100):
            _ = adapter.redis_client

        final_client = adapter.redis_client
        
        # Should still be same client
        assert initial_client is final_client, "Should not create new clients"
        print("✅ No new clients created after 100+ property accesses")


# ============================================================================
# PHASE 2: ASYNC LOCKS TESTS
# ============================================================================

class TestAsyncLocks:
    """Test Phase 2: Async locks for concurrent access safety."""

    async def test_long_term_memory_initializes_locks(self):
        """Verify LongTermMemory initializes lock structures."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        # Verify lock structures exist
        assert hasattr(memory, '_user_locks'), "_user_locks should be initialized"
        assert hasattr(memory, '_lock_manager_lock'), "_lock_manager_lock should be initialized"
        print("✅ LongTermMemory initializes lock structures at __init__")

    async def test_get_user_lock_returns_same_lock_for_same_user(self):
        """Verify _get_user_lock returns same lock for same user (double-checked locking)."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        # Get lock for user1 multiple times
        lock1a = await memory._get_user_lock("user1")
        lock1b = await memory._get_user_lock("user1")
        lock1c = await memory._get_user_lock("user1")

        # Should be same instance
        assert lock1a is lock1b, "Same user should get same lock instance"
        assert lock1b is lock1c, "Same user should get same lock instance"
        print("✅ _get_user_lock returns same lock for same user")

    async def test_get_user_lock_returns_different_locks_for_different_users(self):
        """Verify _get_user_lock returns different locks for different users."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        # Get locks for different users
        lock_user1 = await memory._get_user_lock("user1")
        lock_user2 = await memory._get_user_lock("user2")
        lock_user3 = await memory._get_user_lock("user3")

        # Should be different instances
        assert lock_user1 is not lock_user2, "Different users should get different locks"
        assert lock_user2 is not lock_user3, "Different users should get different locks"
        assert lock_user1 is not lock_user3, "Different users should get different locks"
        print("✅ _get_user_lock returns different locks for different users")

    async def test_same_user_operations_serialize(self):
        """Verify same user's operations serialize (acquire lock sequentially)."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        execution_order = []

        async def operation1():
            lock = await memory._get_user_lock("user1")
            async with lock:
                execution_order.append("op1_start")
                await asyncio.sleep(0.05)  # Simulate work
                execution_order.append("op1_end")

        async def operation2():
            lock = await memory._get_user_lock("user1")
            async with lock:
                execution_order.append("op2_start")
                await asyncio.sleep(0.05)  # Simulate work
                execution_order.append("op2_end")

        # Run both operations concurrently for same user
        await asyncio.gather(operation1(), operation2())

        # Should serialize: op1 should complete before op2 starts
        expected = ["op1_start", "op1_end", "op2_start", "op2_end"]
        assert execution_order == expected, f"Operations should serialize. Got: {execution_order}"
        print("✅ Same user operations serialize (no concurrent access)")

    async def test_different_users_operations_parallelize(self):
        """Verify different users' operations run in parallel."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        execution_order = []
        lock = asyncio.Lock()  # For thread-safe list append

        async def operation_user1():
            user_lock = await memory._get_user_lock("user1")
            async with user_lock:
                async with lock:
                    execution_order.append("u1_start")
                await asyncio.sleep(0.1)  # Longer work
                async with lock:
                    execution_order.append("u1_end")

        async def operation_user2():
            user_lock = await memory._get_user_lock("user2")
            async with user_lock:
                async with lock:
                    execution_order.append("u2_start")
                await asyncio.sleep(0.05)  # Shorter work
                async with lock:
                    execution_order.append("u2_end")

        # Run both operations concurrently for different users
        start = time.time()
        await asyncio.gather(operation_user1(), operation_user2())
        elapsed = time.time() - start

        # Should parallelize: u2 should complete before u1
        # Expected: u1_start, u2_start, u2_end, u1_end
        assert "u2_start" in execution_order[1:], "u2 should start while u1 is working"
        assert "u2_end" in execution_order[:-1], "u2 should end before u1"
        assert elapsed < 0.15, f"Should run in parallel (~0.1s), took {elapsed:.3f}s"
        print(f"✅ Different users operations parallelize (elapsed: {elapsed:.3f}s < 0.15s)")

    async def test_lock_not_held_across_embeddings(self):
        """Verify locks are acquired at right scope (embedder calls happen under lock)."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        # Mock the adapter to track when lock is held
        memory.adapter.search = AsyncMock(return_value=[])

        # Call search
        await memory.search("user1", "test query")

        # Verify adapter.search was called (it should be under lock)
        memory.adapter.search.assert_called_once()
        print("✅ Lock is properly acquired during search operation")


# ============================================================================
# BACKWARD COMPATIBILITY TESTS
# ============================================================================

class TestBackwardCompatibility:
    """Test backward compatibility of changes."""

    def test_redis_config_still_accepts_all_parameters(self):
        """Verify RedisConfig accepts all previous parameters."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            index_name="test_index",
            vector_size=32,
            embedding_model=_toy_embed,
            distance_metric="cosine",
            dedup_mode="similarity",
            dedup_similarity_threshold=0.95,
            use_async=True,
            batch_size=100,
            connection_pool_size=10,
            ttl_seconds=3600,
        )
        
        assert config.redis_url == "redis://localhost:6379"
        assert config.index_name == "test_index"
        assert config.vector_size == 32
        assert config.distance_metric == "cosine"
        assert config.dedup_mode == "similarity"
        assert config.use_async == True
        print("✅ RedisConfig accepts all previous parameters")

    def test_qdrant_config_unchanged(self):
        """Verify QdrantConfig is unaffected by changes."""
        config = QdrantConfig(
            url="http://localhost:6333",
            collection_name="test_collection",
            vector_size=32,
            embedding_model=_toy_embed,
            distance="cosine",
            dedup_mode="similarity",
        )
        
        assert config.url == "http://localhost:6333"
        assert config.collection_name == "test_collection"
        assert config.vector_size == 32
        print("✅ QdrantConfig unchanged and working")

    async def test_long_term_memory_api_signature_unchanged(self):
        """Verify LongTermMemory API signature unchanged."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        # Verify methods exist with same signature
        assert hasattr(memory, 'save'), "save() method should exist"
        assert hasattr(memory, 'search'), "search() method should exist"
        
        # Verify methods are async
        import inspect
        assert inspect.iscoroutinefunction(memory.save), "save() should be async"
        assert inspect.iscoroutinefunction(memory.search), "search() should be async"
        print("✅ LongTermMemory API signature unchanged")

    def test_redis_adapter_api_unchanged(self):
        """Verify RedisAdapter API signature unchanged."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
            use_async=True,
        )
        adapter = RedisAdapter(config)

        # Verify key methods exist
        assert hasattr(adapter, 'upsert_documents'), "upsert_documents() should exist"
        assert hasattr(adapter, 'search'), "search() should exist"
        assert hasattr(adapter, 'delete_by_doc_id'), "delete_by_doc_id() should exist"
        assert hasattr(adapter, 'flush'), "flush() should exist"
        
        # Verify properties/methods for connection management
        assert hasattr(adapter, 'redis_client'), "redis_client property should exist"
        assert hasattr(adapter, 'close'), "close() method should exist"
        print("✅ RedisAdapter API unchanged")


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestIntegration:
    """Test integration of both phases."""

    async def test_long_term_memory_with_redis_initializes_correctly(self):
        """Verify LongTermMemory with Redis backend initializes correctly."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        # Verify setup
        assert memory.backend_type == "redis", "Should detect Redis backend"
        assert memory.adapter is not None, "Should create adapter"
        assert hasattr(memory.adapter, 'redis_client'), "Adapter should have pooled client"
        print("✅ LongTermMemory with Redis initializes correctly with pooling")

    async def test_long_term_memory_with_qdrant_initializes_correctly(self):
        """Verify LongTermMemory with Qdrant backend initializes correctly."""
        config = QdrantConfig(
            url="http://localhost:6333",
            collection_name="test_collection",
            vector_size=32,
            embedding_model=_toy_embed,
        )
        memory = LongTermMemory(config)

        # Verify setup
        assert memory.backend_type == "qdrant", "Should detect Qdrant backend"
        assert memory.adapter is not None, "Should create adapter"
        # Qdrant adapter doesn't have pooling concerns but should work
        print("✅ LongTermMemory with Qdrant initializes correctly")

    async def test_multiple_users_lock_isolation(self):
        """Test that multiple users can operate in parallel without blocking."""
        config = RedisConfig(
            redis_url="redis://localhost:6379",
            embedding_model=_toy_embed,
            vector_size=32,
        )
        memory = LongTermMemory(config)

        timing_data = {}

        async def simulate_user_operation(user_id, duration):
            start = time.time()
            lock = await memory._get_user_lock(user_id)
            async with lock:
                await asyncio.sleep(duration)
            timing_data[user_id] = time.time() - start

        # Simulate 3 users with different operation durations
        total_start = time.time()
        await asyncio.gather(
            simulate_user_operation("user1", 0.1),
            simulate_user_operation("user2", 0.08),
            simulate_user_operation("user3", 0.06),
        )
        total_time = time.time() - total_start

        # Should run in parallel (~0.1s), not sequentially (~0.24s)
        assert total_time < 0.15, f"Should parallelize, took {total_time:.3f}s"
        print(f"✅ Multiple users execute in parallel (total: {total_time:.3f}s < 0.15s)")


# ============================================================================
# RUN TESTS
# ============================================================================

def run_sync_tests():
    """Run synchronous tests."""
    print("\n" + "="*70)
    print("PHASE 1: CONNECTION POOLING TESTS")
    print("="*70)
    
    test_redis = TestRedisConnectionPooling()
    test_redis.test_redis_adapter_creates_pool_at_init()
    test_redis.test_redis_client_property_returns_same_instance()
    test_redis.test_redis_adapter_has_close_method()
    test_redis.test_redis_adapter_no_new_client_on_repeated_access()

    print("\n" + "="*70)
    print("BACKWARD COMPATIBILITY TESTS")
    print("="*70)
    
    test_compat = TestBackwardCompatibility()
    test_compat.test_redis_config_still_accepts_all_parameters()
    test_compat.test_qdrant_config_unchanged()
    test_compat.test_redis_adapter_api_unchanged()


async def run_async_tests():
    """Run asynchronous tests."""
    print("\n" + "="*70)
    print("PHASE 2: ASYNC LOCKS TESTS")
    print("="*70)
    
    test_locks = TestAsyncLocks()
    await test_locks.test_long_term_memory_initializes_locks()
    await test_locks.test_get_user_lock_returns_same_lock_for_same_user()
    await test_locks.test_get_user_lock_returns_different_locks_for_different_users()
    await test_locks.test_same_user_operations_serialize()
    await test_locks.test_different_users_operations_parallelize()
    await test_locks.test_lock_not_held_across_embeddings()

    print("\n" + "="*70)
    print("INTEGRATION TESTS")
    print("="*70)
    
    test_integ = TestIntegration()
    await test_integ.test_long_term_memory_with_redis_initializes_correctly()
    await test_integ.test_long_term_memory_with_qdrant_initializes_correctly()
    await test_integ.test_multiple_users_lock_isolation()

    print("\n" + "="*70)
    print("API SIGNATURE TEST")
    print("="*70)
    await TestBackwardCompatibility().test_long_term_memory_api_signature_unchanged()


if __name__ == "__main__":
    try:
        # Run sync tests
        run_sync_tests()
        
        # Run async tests
        asyncio.run(run_async_tests())
        
        print("\n" + "="*70)
        print("✅ ALL TESTS PASSED - CHANGES ARE COMPATIBLE")
        print("="*70)
        print("\nSummary:")
        print("  ✅ Phase 1: Connection pooling working correctly")
        print("  ✅ Phase 2: Async locks preventing race conditions")
        print("  ✅ Backward compatibility: No API breaking changes")
        print("  ✅ Integration: Both backends work with new changes")
        print()
    except Exception as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
