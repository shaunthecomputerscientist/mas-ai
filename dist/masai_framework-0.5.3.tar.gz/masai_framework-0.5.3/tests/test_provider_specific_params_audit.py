"""
AUDIT: Test what happens when users directly provide provider-specific parameter names
instead of standardized MASAI names.

User might do:
    "max_tokens": 1024           (OpenAI-specific)
    "maxOutputTokens": 2048      (Gemini-specific)
    "logprobs": true             (OpenAI-specific)
    "response_logprobs": true    (Gemini-specific)

Question: Will these be captured and work properly?
Answer: Testing now...
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import pytest
from masai.GenerativeModel.parameter_config import extract_openai_params, extract_gemini_params


class TestProviderSpecificParameterHandling:
    """Test what happens when users directly use provider-specific parameter names"""

    def test_openai_provider_specific_names_directly_in_json(self):
        """
        AUDIT: What if user provides OpenAI-specific names directly?
        
        User config (WRONG WAY):
            "max_tokens": 1024
            "stop": ["END"]
            "logprobs": true
            "top_logprobs": 3
        
        Expected: These should either be captured as-is OR cause an error
        """
        kwargs = {
            "max_tokens": 1024,           # ← Provider-specific name (not standardized)
            "stop": ["END"],              # ← Provider-specific name
            "logprobs": True,             # ← Provider-specific name
            "top_logprobs": 3,            # ← Provider-specific name
            "temperature": 0.3,
        }
        
        extracted = extract_openai_params(kwargs, verbose=True)
        
        print("\n" + "="*80)
        print("TEST: OpenAI with provider-specific param names")
        print("="*80)
        print(f"Input kwargs:  {kwargs}")
        print(f"Extracted:     {extracted}")
        print("="*80)
        
        # The audit: What actually gets extracted?
        assert "temperature" in extracted  # ✅ Shared param works
        
        # CRITICAL AUDIT QUESTIONS:
        # Do provider-specific names get passed through?
        has_max_tokens = "max_tokens" in extracted
        has_stop = "stop" in extracted
        has_logprobs = "logprobs" in extracted
        has_top_logprobs = "top_logprobs" in extracted
        
        print(f"\n✓ max_tokens in output: {has_max_tokens}")
        print(f"✓ stop in output: {has_stop}")
        print(f"✓ logprobs in output: {has_logprobs}")
        print(f"✓ top_logprobs in output: {has_top_logprobs}")
        
        # Get their values if they exist
        if has_max_tokens:
            print(f"  → max_tokens value: {extracted['max_tokens']}")
        if has_stop:
            print(f"  → stop value: {extracted['stop']}")
        if has_logprobs:
            print(f"  → logprobs value: {extracted['logprobs']}")
        if has_top_logprobs:
            print(f"  → top_logprobs value: {extracted['top_logprobs']}")

    def test_gemini_provider_specific_names_directly_in_json(self):
        """
        AUDIT: What if user provides Gemini-specific names directly?
        
        User config (WRONG WAY):
            "maxOutputTokens": 2048
            "stopSequences": ["END"]
            "responseLogprobs": true
            "topK": 40
        
        Expected: These should either be captured as-is OR cause an error
        """
        kwargs = {
            "maxOutputTokens": 2048,       # ← Provider-specific name (not standardized)
            "stopSequences": ["END"],      # ← Provider-specific name
            "responseLogprobs": True,      # ← Provider-specific name
            "topK": 40,                    # ← Provider-specific name
            "temperature": 0.7,
        }
        
        extracted = extract_gemini_params(kwargs, verbose=True)
        
        print("\n" + "="*80)
        print("TEST: Gemini with provider-specific param names")
        print("="*80)
        print(f"Input kwargs:  {kwargs}")
        print(f"Extracted:     {extracted}")
        print("="*80)
        
        # The audit: What actually gets extracted?
        assert "temperature" in extracted  # ✅ Shared param works
        
        # CRITICAL AUDIT QUESTIONS:
        has_max_output = "maxOutputTokens" in extracted
        has_stop_seq = "stopSequences" in extracted
        has_response_logprobs = "responseLogprobs" in extracted
        has_top_k = "topK" in extracted or "top_k" in extracted
        
        print(f"\n✓ maxOutputTokens in output: {has_max_output}")
        print(f"✓ stopSequences in output: {has_stop_seq}")
        print(f"✓ responseLogprobs in output: {has_response_logprobs}")
        print(f"✓ topK in output: {has_top_k}")
        
        # Get their values if they exist
        if has_max_output:
            print(f"  → maxOutputTokens value: {extracted['maxOutputTokens']}")
        if has_stop_seq:
            print(f"  → stopSequences value: {extracted['stopSequences']}")
        if has_response_logprobs:
            print(f"  → responseLogprobs value: {extracted['responseLogprobs']}")
        if has_top_k:
            key = "topK" if "topK" in extracted else "top_k"
            print(f"  → {key} value: {extracted[key]}")

    def test_mixed_standardized_and_provider_specific_openai(self):
        """
        AUDIT: What happens with a mix of both?
        
        Good practice (STANDARDIZED):
            "max_output_tokens": 1024
            "stop_sequences": ["END"]
            "enable_logprobs": true
            "num_logprobs": 3
        
        Mixed approach (BAD):
            "max_output_tokens": 1024       ← Standardized
            "stop": ["END"]                 ← Provider-specific (WRONG)
            "logprobs": true                ← Provider-specific (WRONG)
        """
        kwargs = {
            "max_output_tokens": 1024,  # ✅ Standardized (correct)
            "stop": ["END"],             # ❌ Provider-specific (incorrect)
            "logprobs": True,            # ❌ Provider-specific (incorrect)
            "temperature": 0.3,
        }
        
        extracted = extract_openai_params(kwargs, verbose=True)
        
        print("\n" + "="*80)
        print("TEST: OpenAI with MIXED standardized and provider-specific names")
        print("="*80)
        print(f"Input kwargs:  {kwargs}")
        print(f"Extracted:     {extracted}")
        print("="*80)
        
        # Check what happened
        print(f"\n✓ max_tokens (from max_output_tokens) in output: {'max_tokens' in extracted}")
        print(f"✓ stop (provider-specific) in output: {'stop' in extracted}")
        print(f"✓ logprobs (provider-specific) in output: {'logprobs' in extracted}")
        
        if "max_tokens" in extracted:
            print(f"  → max_tokens value: {extracted['max_tokens']}")
        if "stop" in extracted:
            print(f"  → stop value (from provider-specific): {extracted['stop']}")
        if "logprobs" in extracted:
            print(f"  → logprobs value (from provider-specific): {extracted['logprobs']}")

    def test_openai_mapped_provider_names_filtered_from_gemini(self):
        """
        AUDIT: If user accidentally uses OpenAI names in Gemini config,
        are they safely filtered out?
        
        Gemini config with OpenAI param names (WRONG):
            "max_tokens": 1024          ← This is OpenAI-specific!
            "stop": ["END"]             ← This is OpenAI-specific!
            "logprobs": true            ← This is OpenAI-specific!
        """
        kwargs = {
            "max_tokens": 1024,
            "stop": ["END"],
            "logprobs": True,
            "temperature": 0.7,
        }
        
        extracted = extract_gemini_params(kwargs, verbose=True)
        
        print("\n" + "="*80)
        print("TEST: Gemini with OpenAI param names (cross-provider)")
        print("="*80)
        print(f"Input kwargs:  {kwargs}")
        print(f"Extracted:     {extracted}")
        print("="*80)
        
        print(f"\n✓ max_tokens filtered out: {'max_tokens' not in extracted}")
        print(f"✓ stop filtered out: {'stop' not in extracted}")
        print(f"✓ logprobs filtered out: {'logprobs' not in extracted}")
        print(f"✓ temperature preserved: {'temperature' in extracted}")


if __name__ == "__main__":
    # Run the audit tests with verbose output
    test = TestProviderSpecificParameterHandling()
    
    print("\n" + "█"*80)
    print("AUDIT: Provider-Specific Parameter Handling")
    print("█"*80)
    
    test.test_openai_provider_specific_names_directly_in_json()
    test.test_gemini_provider_specific_names_directly_in_json()
    test.test_mixed_standardized_and_provider_specific_openai()
    test.test_openai_mapped_provider_names_filtered_from_gemini()
    
    print("\n" + "█"*80)
    print("AUDIT COMPLETE")
    print("█"*80)
