"""
Test to verify that stop_sequences parameter is handled correctly.

This test verifies that:
1. stop_sequences is properly aliased to stop in ChatOpenAI
2. stop_sequences is filtered out before being passed to the API
3. The error "AsyncCompletions.create() got an unexpected keyword argument 'stop_sequences'" is resolved
"""

import os
import sys

# Ensure 'src' is on path for local imports
sys.path.insert(0, os.path.abspath("src"))

from masai.GenerativeModel.vanilla_wrappers import ChatOpenAI


def test_stop_sequences_alias():
    """Test that ChatOpenAI accepts stop_sequences parameter."""
    print("\nTest 1: ChatOpenAI accepts stop_sequences parameter...")
    
    try:
        # Test 1a: stop_sequences as positional parameter
        model = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.7,
            api_key="test-key",
            stop_sequences=["END", "STOP"]
        )
        assert model.stop == ["END", "STOP"], f"Expected stop=['END', 'STOP'], got {model.stop}"
        print("  ✅ ChatOpenAI accepts stop_sequences parameter and maps to stop")
    except TypeError as e:
        print(f"  ❌ FAILED: {e}")
        return False

    try:
        # Test 1b: stop parameter still works
        model = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.7,
            api_key="test-key",
            stop="END"
        )
        assert model.stop == "END", f"Expected stop='END', got {model.stop}"
        print("  ✅ ChatOpenAI still accepts stop parameter directly")
    except TypeError as e:
        print(f"  ❌ FAILED: {e}")
        return False

    try:
        # Test 1c: stop takes precedence over stop_sequences
        model = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.7,
            api_key="test-key",
            stop="PREFERRED",
            stop_sequences=["IGNORED", "ALSO_IGNORED"]
        )
        assert model.stop == "PREFERRED", f"Expected stop='PREFERRED', got {model.stop}"
        print("  ✅ stop parameter takes precedence over stop_sequences")
    except TypeError as e:
        print(f"  ❌ FAILED: {e}")
        return False

    return True


def test_stop_sequences_filtered_from_extra_kwargs():
    """Test that stop_sequences doesn't end up in extra_kwargs."""
    print("\nTest 2: stop_sequences filtered from extra_kwargs...")
    
    try:
        model = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.7,
            api_key="test-key",
            stop_sequences=["END", "STOP"]
        )
        
        # Verify stop_sequences is NOT in extra_kwargs (it should be handled separately)
        assert "stop_sequences" not in model.extra_kwargs, f"stop_sequences should not be in extra_kwargs, got {model.extra_kwargs}"
        assert "stop" not in model.extra_kwargs, f"stop should not be in extra_kwargs (it's stored as self.stop), got {model.extra_kwargs}"
        print("  ✅ stop_sequences correctly filtered from extra_kwargs")
        return True
    except AssertionError as e:
        print(f"  ❌ FAILED: {e}")
        return False


def test_mapped_parameters_filtered():
    """Test that all mapped parameters are filtered from extra_kwargs."""
    print("\nTest 3: All mapped parameters filtered from extra_kwargs...")
    
    try:
        model = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.7,
            api_key="test-key",
            max_output_tokens=2048,
            stop_sequences=["END"],
            enable_logprobs=True,
            num_logprobs=5,
            unknown_param="should_pass_through"  # This should NOT be filtered
        )
        
        # Verify mapped parameters are NOT in extra_kwargs
        assert "max_output_tokens" not in model.extra_kwargs, "max_output_tokens should be filtered"
        assert "stop_sequences" not in model.extra_kwargs, "stop_sequences should be filtered"
        assert "enable_logprobs" not in model.extra_kwargs, "enable_logprobs should be filtered"
        assert "num_logprobs" not in model.extra_kwargs, "num_logprobs should be filtered"
        
        # But unknown parameters should pass through for forward compatibility
        assert "unknown_param" in model.extra_kwargs, "unknown_param should pass through for forward compatibility"
        assert model.extra_kwargs["unknown_param"] == "should_pass_through"
        
        print("  ✅ Mapped parameters filtered, unknown parameters pass through")
        return True
    except AssertionError as e:
        print(f"  ❌ FAILED: {e}")
        return False


def test_request_params_dont_include_stop_sequences():
    """Test that _prepare_request_params doesn't include stop_sequences."""
    print("\nTest 4: Request params use 'stop' not 'stop_sequences'...")
    
    try:
        model = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0.7,
            api_key="test-key",
            stop_sequences=["END", "STOP"]
        )
        
        # Prepare request params with a dummy message
        messages = [{"role": "user", "content": "test"}]
        params = model._prepare_request_params(messages)
        
        # Verify request params use "stop" not "stop_sequences"
        assert "stop_sequences" not in params, f"Request params should not include 'stop_sequences', got {params.keys()}"
        assert "stop" in params, f"Request params should include 'stop', got {params.keys()}"
        assert params["stop"] == ["END", "STOP"], f"Expected stop=['END', 'STOP'], got {params['stop']}"
        
        print("  ✅ Request params correctly use 'stop' not 'stop_sequences'")
        return True
    except AssertionError as e:
        print(f"  ❌ FAILED: {e}")
        return False
    except Exception as e:
        print(f"  ❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("="*70)
    print("TESTING STOP_SEQUENCES PARAMETER FIX")
    print("="*70)
    
    all_passed = True
    
    all_passed &= test_stop_sequences_alias()
    all_passed &= test_stop_sequences_filtered_from_extra_kwargs()
    all_passed &= test_mapped_parameters_filtered()
    all_passed &= test_request_params_dont_include_stop_sequences()
    
    print("\n" + "="*70)
    if all_passed:
        print("✅ ALL TESTS PASSED - stop_sequences fix is working")
        print("="*70)
        print("\nThe error 'AsyncCompletions.create() got an unexpected keyword argument")
        print("'stop_sequences'' should no longer occur.")
        sys.exit(0)
    else:
        print("❌ SOME TESTS FAILED")
        print("="*70)
        sys.exit(1)
